echo Hej hej
echo This was done using Vim
echo "How do i exit VIM?!?!?"
echo Top answer on stackoverflow:
echo 	"'I've been here since 1998'"
